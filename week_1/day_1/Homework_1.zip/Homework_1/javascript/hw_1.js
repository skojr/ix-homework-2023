function showAlert() {
    alert("Redirecting to LinkedIn...");
}